# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Mail: Servers and clients for POP3, ESMTP, and IMAP.
"""

from twisted.mail._version import version
__version__ = version.short()
